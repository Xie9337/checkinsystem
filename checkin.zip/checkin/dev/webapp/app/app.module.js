'use strict';

// Define the `attendU` module
angular.module('attendU', [
  'ngAnimate',
  'ngCookies',
  'ui.router',
  'ngFlash',
  'ngAnimate'
]);
