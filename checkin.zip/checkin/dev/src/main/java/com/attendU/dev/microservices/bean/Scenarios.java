package com.attendU.dev.microservices.bean;

import lombok.Getter;
import lombok.Setter;

public class Scenarios{
	@Getter@Setter
	private Long id;
	
	@Getter@Setter
	private String text;
}